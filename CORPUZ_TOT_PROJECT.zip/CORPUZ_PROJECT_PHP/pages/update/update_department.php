<?php
    $id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: missing ID.');
    include_once "../../config/database.php";
    include_once "../../classes/departments.php";
     include_once "../header.php";
    $db = new Database();
    $dbase = $db->getConnection();

    $department = new Department($dbase);
    $department->department_id = $id;
    $department->edit();

    if(isset($_POST['btn_submit'])){
        $department->name = $_POST['name'];
        $department->short_name = $_POST['short_name'];

        if($department->update()){
            echo ' <div class="alert alert-success" role="alert">
            <strong>Successfully updated</strong>
            </div>';    
        }
       
    }
?>

<p>Update a Department</p>

<form method="POST" action="<?php echo "update_department.php?id={$id}";?>">
  <div class="col-md-4">
    <label for="name" class="form-label">Department Name</label>
    <input type="text" class="form-control" id="name" name='name' placeholder=' Department Name' required
      value="<?php echo $department->name ;?>">
  </div>
  <div class="col-md-4">
    <label for="short_name" class="form-label">Department Short Name</label>
    <input type="text" class="form-control" id='short_name' name='short_name' placeholder=' Department Short Name'
      required value="<?php echo $department->short_name ;?>">
  </div>
  <div class="col-12">
    <a name='btn_update' id='btn_update' class='btn btn-outline-dark ms-2' href='/pages/dashboard.php' role=' button'>
      <i class="fas fa-window-close me-1"></i>Cancel

    </a>
    <button class="btn btn-outline-dark ms-2" type="submit" name="btn_submit">
      <i class="fas fa-plus me-2"></i>
      Save</button>
  </div>
</form>
<?php 
include_once "../footer.php";
?>