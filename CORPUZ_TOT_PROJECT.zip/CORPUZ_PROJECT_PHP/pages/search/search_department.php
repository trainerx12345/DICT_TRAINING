<?php
    include_once "../../config/database.php";
    include_once "../../classes/departments.php";
    $db = new Database();
    $dbase = $db->getConnection();
 
    $deparment = new Department($dbase);
    $department->search = $_POST['searchValue'];
    
    $deparment->search();
      
?>