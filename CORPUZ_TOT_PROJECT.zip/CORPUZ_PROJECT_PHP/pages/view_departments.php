<?php 
   include '../config/database.php';
   include '../classes/departments.php';

   $db = new Database();
   $dbase = $db->getConnection();

   $deparment = new Department($dbase);
   $data = $deparment->read();
   
   ?>
<!-- Section Employees-->
<section class="py-5 vh-100" id="deparments">
  <div class="container">
    <!-- Register Modal -->
    <div id="create_department" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true"
      data-bs-keyboard="false" data-bs-backdrop="static">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-3 shadow">
          <div class="modal-header bg-primary text-white">
            <h2 class="modal-title">Create a Department</h2>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form class="g-3 needs-validation" action="./create/create_department.php" method="post">
              <div class="mb-3">
                <label for="name" class="form-label">Department Name</label>
                <input type="text" class="form-control" id="name" name='name' placeholder='Enter Department Name'
                  required>
              </div>
              <div class="mb-3">
                <label for="short_name" class="form-label">Department Short Name</label>
                <input type="text" class="form-control" id='short_name' name='short_name'
                  placeholder='Enter Department Short Name' required>
              </div>
              <div class="text-center">
                <button id="cancelButton" class="btn btn-outline-danger me-3" data-bs-dismiss="modal">
                  <i class="fas fa-window-close me-1"></i>Cancel
                </button>
                <button class="btn btn-primary" type="submit" name="btn_submit">
                  <i class="fas fa-plus me-2"></i>Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Update Modal -->
    <div id="update_department" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true"
      data-bs-keyboard="false" data-bs-backdrop="static">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-3 shadow">
          <div class="modal-header bg-primary text-white">
            <h2 class="modal-title">Update Department</h2>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form class="g-3 needs-validation" action="<?php echo "update_department.php?id={$id}";?>" method="post">
              <div class="col-md-4">
                <label for="name" class="form-label">Department Name</label>
                <input type="text" class="form-control" id="name" name='name' placeholder=' Department Name' required
                  value="<?php echo $department->name ;?>">
              </div>
              <div class="col-md-4">
                <label for="short_name" class="form-label">Department Short Name</label>
                <input type="text" class="form-control" id='short_name' name='short_name'
                  placeholder=' Department Short Name' required value="<?php echo $department->short_name ;?>">
              </div>
              <div class="col-12">
                <a name='btn_update' id='btn_update' class='btn btn-outline-dark ms-2' href='/pages/dashboard.php'
                  role=' button'>
                  <i class="fas fa-window-close me-1"></i>Cancel

                </a>
                <button class="btn btn-outline-dark ms-2" type="submit" name="btn_submit">
                  <i class="fas fa-plus me-2"></i>
                  Save</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>




    <h2 class="text-center mb-4">List of Departments</h2>
    <div class="table-responsive">
      <div class='d-flex align-items-center gap-3 my-3'>
        <button class="btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#create_department">
          <i class="fas fa-plus me-2"></i>
          Add Department
        </button>
        <form class="d-flex gap-2 flex-fill">
          <input class="form-control flex-grow-1" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-dark" type="submit">Search</button>
        </form>
      </div>

      <table class="table table-bordered" id='data-tables'>
        <thead>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Short Name</th>
            <th style="width:200px;">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php
       while($row=$data->fetch(PDO::FETCH_ASSOC)){
         extract($row);
                echo"<tr>
                    <td> $id </td>
                    <td> $name </td>
                    <td> $short_name </td>
                    <td> 
                     <a name='btn_update' id='btn_update' class='btn btn-primary' href='/pages/update/update_department.php?id=$id role='button'>Update</a>  
                     <a delete-id='$id' class='btn btn-danger delete-department'>Delete</a>
                    </td> 
                </tr>";
            }
            ?>
        </tbody>

      </table>
    </div>
  </div>
</section>

<script>
  const cancelButton = document.getElementById('cancelButton');
  const modal = new bootstrap.Modal(document.getElementById('create_department'));

  cancelButton.addEventListener('click', function () {
    // Set aria-hidden="true" for the modal element
    document.getElementById('create_department').setAttribute('aria-hidden', 'true');
    // Close the modal
    modal.hide();
  });
</script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"
  integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script>
  $(document).on('click', '.delete-department', function () {
    var id = $(this).attr('delete-id');
    console.log(id);
    var q = confirm("Are you sure?");

    if (q == true) {
      $.post('/pages/delete/delete_department.php', {
        deparment_id: id
      }, function (data) {
        location.reload();
      }).fail(function () {
        alert('Unable to delete.');
      });
    }
  });
</script>